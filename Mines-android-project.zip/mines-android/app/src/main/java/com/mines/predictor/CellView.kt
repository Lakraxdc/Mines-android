package com.mines.predictor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

class CellView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : View(context, attrs, defStyle) {

    var cellState: CellState = CellState(0, 0)
        set(value) { field = value; invalidate() }

    var isGameActive: Boolean = false
        set(value) { field = value; invalidate() }

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val rect = RectF()

    private fun probColors(p: Float): Triple<Int, Int, Int> = when {
        p <= 0.00f -> Triple(Color.parseColor("#071a10"), Color.parseColor("#16a34a"), Color.parseColor("#4ade80"))
        p < 0.10f -> Triple(Color.parseColor("#0a1f14"), Color.parseColor("#22c55e"), Color.parseColor("#86efac"))
        p < 0.18f -> Triple(Color.parseColor("#121f08"), Color.parseColor("#84cc16"), Color.parseColor("#bef264"))
        p < 0.28f -> Triple(Color.parseColor("#1f1a05"), Color.parseColor("#eab308"), Color.parseColor("#fcd34d"))
        p < 0.45f -> Triple(Color.parseColor("#1f1005"), Color.parseColor("#f97316"), Color.parseColor("#fdba74"))
        else      -> Triple(Color.parseColor("#1f0505"), Color.parseColor("#ef4444"), Color.parseColor("#fca5a5"))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val r = 14f
        rect.set(3f, 3f, w - 3f, h - 3f)

        when {
            cellState.isMine -> {
                bgPaint.color = Color.parseColor("#1a0505")
                borderPaint.color = Color.parseColor("#ef4444")
                canvas.drawRoundRect(rect, r, r, bgPaint)
                canvas.drawRoundRect(rect, r, r, borderPaint)
                textPaint.textSize = h * 0.42f
                textPaint.color = Color.WHITE
                canvas.drawText("💣", w / 2f, h / 2f + textPaint.textSize * 0.35f, textPaint)
            }
            cellState.isSafe -> {
                bgPaint.color = Color.parseColor("#071a10")
                borderPaint.color = Color.parseColor("#22c55e")
                canvas.drawRoundRect(rect, r, r, bgPaint)
                canvas.drawRoundRect(rect, r, r, borderPaint)
                textPaint.textSize = h * 0.38f
                textPaint.color = Color.parseColor("#4ade80")
                canvas.drawText("✓", w / 2f, h / 2f + textPaint.textSize * 0.35f, textPaint)
            }
            isGameActive && cellState.probability != null -> {
                val (bg, border, txt) = probColors(cellState.probability!!)
                bgPaint.color = bg
                borderPaint.color = border
                canvas.drawRoundRect(rect, r, r, bgPaint)
                canvas.drawRoundRect(rect, r, r, borderPaint)
                val pct = (cellState.probability!! * 100).toInt()
                textPaint.textSize = if (pct >= 100) h * 0.22f else h * 0.26f
                textPaint.color = txt
                canvas.drawText("${pct}%", w / 2f, h / 2f + textPaint.textSize * 0.35f, textPaint)
            }
            else -> {
                bgPaint.color = Color.parseColor("#080f1e")
                borderPaint.color = Color.parseColor("#141f35")
                canvas.drawRoundRect(rect, r, r, bgPaint)
                canvas.drawRoundRect(rect, r, r, borderPaint)
                textPaint.textSize = h * 0.26f
                textPaint.color = Color.parseColor("#1e3050")
                canvas.drawText("?", w / 2f, h / 2f + textPaint.textSize * 0.35f, textPaint)
            }
        }
    }
}
