package com.mines.predictor

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.mines.predictor.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MinesViewModel by viewModels()
    private val cellViews = Array(5) { arrayOfNulls<CellView>(5) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupGrid()
        setupButtons()
        observeState()
    }

    private fun setupGrid() {
        binding.gridContainer.removeAllViews()
        val screenWidth = resources.displayMetrics.widthPixels
        val padding = dpToPx(24)
        val gap = dpToPx(4)
        val cellSize = (screenWidth - padding * 2 - gap * 4) / 5

        for (row in 0 until 5) {
            val rowLayout = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                if (row > 0) {
                    val lp = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    lp.topMargin = gap
                    layoutParams = lp
                }
            }
            for (col in 0 until 5) {
                val cell = CellView(this)
                cell.cellState = CellState(row, col)
                val lp = LinearLayout.LayoutParams(cellSize, cellSize)
                if (col > 0) lp.leftMargin = gap
                cell.layoutParams = lp
                cell.setOnClickListener { viewModel.clickCell(row, col) }
                cellViews[row][col] = cell
                rowLayout.addView(cell)
            }
            binding.gridContainer.addView(rowLayout)
        }
    }

    private fun setupButtons() {
        binding.btnFetch.setOnClickListener { viewModel.fetchSession() }
        binding.btnNewGame.setOnClickListener { viewModel.newGame() }
        binding.btnCashout.setOnClickListener { viewModel.cashout() }
    }

    private fun observeState() {
        viewModel.uiState.observe(this) { state ->
            // Update loading
            binding.progressBar.visibility = if (state.loading) View.VISIBLE else View.GONE
            binding.btnFetch.isEnabled = !state.loading
            binding.btnNewGame.isEnabled = !state.loading
            binding.btnCashout.isEnabled = !state.loading && state.gameState == GameState.ACTIVE && state.safeCount > 0

            // Session info
            binding.tvSessionId.text = if (state.sessionId != null)
                "ID: ${state.sessionId.take(12)}..." else "No session"

            binding.tvBalance.text = if (state.balance > 0) "₹${String.format("%.2f", state.balance)}" else "—"
            binding.tvRate.text = if (state.currentRate > 0) "${state.currentRate}×" else "—"

            // Game state badge
            val (stateText, stateColor) = when (state.gameState) {
                GameState.IDLE -> "IDLE" to Color.parseColor("#2a4060")
                GameState.ACTIVE -> "ACTIVE" to Color.parseColor("#4ade80")
                GameState.WON -> "WON" to Color.parseColor("#22c55e")
                GameState.LOST -> "LOST" to Color.parseColor("#f87171")
            }
            binding.tvGameState.text = stateText
            binding.tvGameState.setTextColor(stateColor)

            // Stats
            binding.tvSafeCount.text = "${state.safeCount}"
            binding.tvMineCount.text = "2"
            binding.tvUnknownCount.text = "${25 - state.safeCount - state.cells.count { it.isMine }}"

            // Status message
            binding.tvStatus.text = state.statusMessage
            binding.tvStatus.setTextColor(
                if (state.statusMessage.contains("MINE") || state.statusMessage.contains("Failed"))
                    Color.parseColor("#f87171")
                else if (state.statusMessage.contains("✓") || state.statusMessage.contains("💰"))
                    Color.parseColor("#4ade80")
                else Color.parseColor("#4a7ab5")
            )

            // Error
            if (state.errorMessage != null) {
                binding.tvError.visibility = View.VISIBLE
                binding.tvError.text = "⚠️ ${state.errorMessage}"
            } else {
                binding.tvError.visibility = View.GONE
            }

            // Win display
            if (state.gameState == GameState.WON && state.winAmount > 0) {
                binding.winCard.visibility = View.VISIBLE
                binding.tvWinAmount.text = "₹${String.format("%.2f", state.winAmount)}"
                binding.tvWinRate.text = "${state.currentRate}×"
            } else {
                binding.winCard.visibility = View.GONE
            }

            // Update grid cells
            val isActive = state.gameState == GameState.ACTIVE
            for (row in 0 until 5) {
                for (col in 0 until 5) {
                    val cellView = cellViews[row][col] ?: continue
                    val cellState = state.cells.find { it.row == row && it.col == col }
                        ?: CellState(row, col)
                    cellView.cellState = cellState
                    cellView.isGameActive = isActive
                    cellView.isEnabled = isActive && !cellState.isSafe && !cellState.isMine && !state.loading
                }
            }
        }
    }

    private fun dpToPx(dp: Int): Int = (dp * resources.displayMetrics.density).toInt()
}
