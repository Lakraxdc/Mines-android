package com.mines.predictor

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

object ApiConfig {
    const val BASE_URL = "https://prod-instant-1win-v2-backend-go-rnd.gamedev-tech.cc/v2/mines"
    const val AUTH_TOKEN = "2c9932642581867fc5cdc84b323c59e1c38ed940e8f654a3cfeaf54e9accffb9bb808f326065153673f1233e57268a191db4ef0bffa3dbfe6a4eb7c4a4e24343cffb8a4a2002e7bb54c50afa4a1d39084e98ea62ad65687ec09fdfbff9f973f928eff4eeaea39cebb4b4b6f306486efbac4671d6810767582549e7d8c1fdad89e15206b20e2bf3770c8fcb0793145351d87dc6e715ccab6cb60adf30dc.e072d5308519fad9ff1a9ba9e96520f3.077dee8d-c923-4c02-9bee-757573662e69"
    const val INTEGRATION_KEY = "vgsonewin_mines"
    const val QS = "?thanus_debug=false&integration_key=$INTEGRATION_KEY"
    const val ORIGIN = "https://1play.gamedev-tech.cc"
    const val USER_AGENT = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36"
}

data class Round(val row: Int, val col: Int, val result: Int) // result: 2=safe, 1=mine
data class SessionData(
    val id: String,
    val state: String,
    val rounds: List<Round>,
    val rate: Double,
    val balance: Double,
    val minesCount: Int = 2
)
data class RoundResult(val row: Int, val col: Int, val result: Int, val rate: Double, val balance: Double)
data class CashoutResult(val win: Double, val rate: Double, val balance: Double, val field: Array<IntArray>?)
data class ApiError(val message: String, val type: String = "")

sealed class ApiResult<out T> {
    data class Success<T>(val data: T) : ApiResult<T>()
    data class Error(val error: ApiError) : ApiResult<Nothing>()
}

class MinesApiClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private fun buildRequest(url: String): Request.Builder = Request.Builder()
        .url(url)
        .header("x-auth-token", ApiConfig.AUTH_TOKEN)
        .header("x-request-id", UUID.randomUUID().toString())
        .header("Accept", "application/json, text/plain, */*")
        .header("Content-Type", "application/json")
        .header("Origin", ApiConfig.ORIGIN)
        .header("Referer", "${ApiConfig.ORIGIN}/")
        .header("User-Agent", ApiConfig.USER_AGENT)

    private suspend fun executeRequest(request: Request): ApiResult<JSONObject> =
        withContext(Dispatchers.IO) {
            try {
                val response = client.newCall(request).execute()
                val body = response.body?.string() ?: "{}"
                val json = JSONObject(body)
                if (response.isSuccessful) {
                    ApiResult.Success(json)
                } else {
                    val type = json.optString("type", "api_error")
                    ApiResult.Error(ApiError("HTTP ${response.code}: $type", type))
                }
            } catch (e: Exception) {
                ApiResult.Error(ApiError(e.message ?: "Network error"))
            }
        }

    suspend fun fetchActualSession(): ApiResult<SessionData> {
        val request = buildRequest("${ApiConfig.BASE_URL}/session/actual${ApiConfig.QS}").get().build()
        return when (val result = executeRequest(request)) {
            is ApiResult.Success -> {
                try {
                    val s = result.data.getJSONObject("session")
                    val balance = result.data.optDouble("balance", 0.0)
                    val roundsList = mutableListOf<Round>()
                    val rounds = s.optJSONArray("rounds")
                    if (rounds != null) {
                        for (i in 0 until rounds.length()) {
                            val r = rounds.getJSONObject(i)
                            val data = r.getJSONObject("data")
                            roundsList.add(Round(data.getInt("row"), data.getInt("col"), r.getInt("result")))
                        }
                    }
                    ApiResult.Success(SessionData(
                        id = s.getString("id"),
                        state = s.getString("state"),
                        rounds = roundsList,
                        rate = s.optDouble("rate", 0.0),
                        balance = balance
                    ))
                } catch (e: Exception) {
                    ApiResult.Error(ApiError("Parse error: ${e.message}"))
                }
            }
            is ApiResult.Error -> result
        }
    }

    suspend fun generateSession(minesCount: Int = 2): ApiResult<SessionData> {
        val body = JSONObject().apply { put("minesCount", minesCount) }
            .toString().toRequestBody("application/json".toMediaType())
        val request = buildRequest("${ApiConfig.BASE_URL}/session/generate${ApiConfig.QS}")
            .put(body).build()
        return when (val result = executeRequest(request)) {
            is ApiResult.Success -> {
                try {
                    val json = result.data
                    ApiResult.Success(SessionData(
                        id = json.getString("id"),
                        state = "Active",
                        rounds = emptyList(),
                        rate = 0.0,
                        balance = 0.0,
                        minesCount = minesCount
                    ))
                } catch (e: Exception) {
                    ApiResult.Error(ApiError("Parse error: ${e.message}"))
                }
            }
            is ApiResult.Error -> result
        }
    }

    suspend fun playRound(sessionId: String, row: Int, col: Int, betAmount: Double = 8.5): ApiResult<RoundResult> {
        val body = JSONObject().apply {
            put("bet_amount", betAmount)
            put("row", row)
            put("col", col)
        }.toString().toRequestBody("application/json".toMediaType())
        val request = buildRequest("${ApiConfig.BASE_URL}/session/$sessionId/round${ApiConfig.QS}")
            .post(body).build()
        return when (val result = executeRequest(request)) {
            is ApiResult.Success -> {
                try {
                    val json = result.data
                    val rounds = json.getJSONArray("rounds")
                    val lastRound = rounds.getJSONObject(rounds.length() - 1)
                    val resultCode = lastRound.getInt("result")
                    val session = json.getJSONObject("session")
                    val balance = json.optDouble("balance", 0.0)
                    ApiResult.Success(RoundResult(row, col, resultCode, session.optDouble("rate", 0.0), balance))
                } catch (e: Exception) {
                    ApiResult.Error(ApiError("Parse error: ${e.message}"))
                }
            }
            is ApiResult.Error -> result
        }
    }

    suspend fun cashout(sessionId: String): ApiResult<CashoutResult> {
        val request = buildRequest("${ApiConfig.BASE_URL}/session/$sessionId/cashout${ApiConfig.QS}")
            .get().build()
        return when (val result = executeRequest(request)) {
            is ApiResult.Success -> {
                try {
                    val json = result.data
                    val session = json.getJSONObject("session")
                    val balance = json.optDouble("balance", 0.0)
                    val fieldJson = json.optJSONObject("censored_game_data")?.optJSONArray("field")
                    var field: Array<IntArray>? = null
                    if (fieldJson != null && fieldJson.length() > 0) {
                        field = Array(fieldJson.length()) { r ->
                            val row = fieldJson.getJSONArray(r)
                            IntArray(row.length()) { c -> row.getInt(c) }
                        }
                    }
                    ApiResult.Success(CashoutResult(
                        win = session.optDouble("cash", 0.0),
                        rate = session.optDouble("rate", 0.0),
                        balance = balance,
                        field = field
                    ))
                } catch (e: Exception) {
                    ApiResult.Error(ApiError("Parse error: ${e.message}"))
                }
            }
            is ApiResult.Error -> result
        }
    }
}
