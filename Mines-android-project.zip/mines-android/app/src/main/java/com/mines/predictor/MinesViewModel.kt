package com.mines.predictor

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

enum class GameState { IDLE, ACTIVE, WON, LOST }

data class CellState(
    val row: Int,
    val col: Int,
    val isSafe: Boolean = false,
    val isMine: Boolean = false,
    val probability: Float? = null
)

data class UiState(
    val loading: Boolean = false,
    val sessionId: String? = null,
    val gameState: GameState = GameState.IDLE,
    val cells: List<CellState> = List(25) { CellState(it / 5, it % 5) },
    val balance: Double = 0.0,
    val currentRate: Double = 0.0,
    val winAmount: Double = 0.0,
    val statusMessage: String = "Tap FETCH SESSION to connect to your 1Win game",
    val errorMessage: String? = null,
    val safeCount: Int = 0,
    val mineCount: Int = 2
)

class MinesViewModel : ViewModel() {
    private val api = MinesApiClient()

    private val _uiState = MutableLiveData(UiState())
    val uiState: LiveData<UiState> = _uiState

    private val GRID = 5
    private val TOTAL_MINES = 2

    private fun update(block: UiState.() -> UiState) {
        _uiState.value = _uiState.value!!.block()
    }

    private fun computeProbs(cells: List<CellState>): List<CellState> {
        val safeCells = cells.count { it.isSafe }
        val mineCells = cells.count { it.isMine }
        val unknowns = cells.count { !it.isSafe && !it.isMine }
        val remainingMines = TOTAL_MINES - mineCells
        val prob = if (unknowns > 0 && remainingMines > 0) remainingMines.toFloat() / unknowns.toFloat() else 0f

        return cells.map { cell ->
            if (!cell.isSafe && !cell.isMine) {
                cell.copy(probability = prob)
            } else {
                cell.copy(probability = null)
            }
        }
    }

    fun fetchSession() {
        viewModelScope.launch {
            update { copy(loading = true, errorMessage = null, statusMessage = "Connecting to 1Win API...") }
            when (val result = api.fetchActualSession()) {
                is ApiResult.Success -> {
                    val session = result.data
                    val cells = buildCellsFromRounds(session.rounds)
                    val withProbs = computeProbs(cells)
                    val safeCount = cells.count { it.isSafe }
                    val state = when (session.state.lowercase()) {
                        "active" -> GameState.ACTIVE
                        "win" -> GameState.WON
                        "lose", "lost" -> GameState.LOST
                        else -> GameState.IDLE
                    }
                    update {
                        copy(
                            loading = false,
                            sessionId = session.id,
                            gameState = state,
                            cells = withProbs,
                            balance = session.balance,
                            currentRate = session.rate,
                            safeCount = safeCount,
                            statusMessage = "✓ Session loaded · Safe: $safeCount · Mines: $TOTAL_MINES hidden",
                            errorMessage = null
                        )
                    }
                }
                is ApiResult.Error -> {
                    update {
                        copy(
                            loading = false,
                            errorMessage = result.error.message,
                            statusMessage = "Failed to connect"
                        )
                    }
                }
            }
        }
    }

    fun newGame() {
        viewModelScope.launch {
            update { copy(loading = true, errorMessage = null, statusMessage = "Generating new session...") }
            when (val result = api.generateSession(TOTAL_MINES)) {
                is ApiResult.Success -> {
                    val session = result.data
                    val freshCells = computeProbs(List(25) { CellState(it / 5, it % 5) })
                    update {
                        copy(
                            loading = false,
                            sessionId = session.id,
                            gameState = GameState.ACTIVE,
                            cells = freshCells,
                            currentRate = 0.0,
                            winAmount = 0.0,
                            safeCount = 0,
                            statusMessage = "🎲 New game ready! ${TOTAL_MINES} mines in ${GRID}×${GRID} grid",
                            errorMessage = null
                        )
                    }
                }
                is ApiResult.Error -> {
                    update {
                        copy(
                            loading = false,
                            errorMessage = result.error.message,
                            statusMessage = "Failed to start new game"
                        )
                    }
                }
            }
        }
    }

    fun clickCell(row: Int, col: Int) {
        val state = _uiState.value ?: return
        if (state.loading || state.gameState != GameState.ACTIVE || state.sessionId == null) return
        val cell = state.cells.find { it.row == row && it.col == col } ?: return
        if (cell.isSafe || cell.isMine) return

        viewModelScope.launch {
            update { copy(loading = true, statusMessage = "Revealing R${row} C${col}...") }
            when (val result = api.playRound(state.sessionId, row, col)) {
                is ApiResult.Success -> {
                    val roundResult = result.data
                    val isSafe = roundResult.result == 2
                    val currentCells = _uiState.value!!.cells.map { c ->
                        if (c.row == row && c.col == col) {
                            c.copy(isSafe = isSafe, isMine = !isSafe, probability = null)
                        } else c
                    }
                    val withProbs = if (isSafe) computeProbs(currentCells) else currentCells
                    val safeCount = withProbs.count { it.isSafe }
                    val newGameState = if (isSafe) GameState.ACTIVE else GameState.LOST

                    update {
                        copy(
                            loading = false,
                            cells = withProbs,
                            gameState = newGameState,
                            currentRate = roundResult.rate,
                            balance = roundResult.balance,
                            safeCount = safeCount,
                            statusMessage = if (isSafe)
                                "✓ Safe! R${row} C${col} · Multiplier: ${roundResult.rate}×"
                            else
                                "💥 MINE HIT at R${row} C${col}! Game over."
                        )
                    }
                }
                is ApiResult.Error -> {
                    update {
                        copy(
                            loading = false,
                            errorMessage = result.error.message,
                            statusMessage = "Cell click failed"
                        )
                    }
                }
            }
        }
    }

    fun cashout() {
        val state = _uiState.value ?: return
        if (state.gameState != GameState.ACTIVE || state.sessionId == null || state.safeCount == 0) return

        viewModelScope.launch {
            update { copy(loading = true, statusMessage = "Cashing out...") }
            when (val result = api.cashout(state.sessionId)) {
                is ApiResult.Success -> {
                    val cashoutResult = result.data
                    // Reveal mine positions from field
                    val updatedCells = _uiState.value!!.cells.map { cell ->
                        val fieldVal = cashoutResult.field?.getOrNull(cell.row)?.getOrNull(cell.col)
                        if (fieldVal == 1 && !cell.isSafe) {
                            cell.copy(isMine = true, probability = null)
                        } else cell
                    }
                    update {
                        copy(
                            loading = false,
                            cells = updatedCells,
                            gameState = GameState.WON,
                            winAmount = cashoutResult.win,
                            currentRate = cashoutResult.rate,
                            balance = cashoutResult.balance,
                            statusMessage = "💰 Cashed out ₹${cashoutResult.win} @ ${cashoutResult.rate}×"
                        )
                    }
                }
                is ApiResult.Error -> {
                    update {
                        copy(
                            loading = false,
                            errorMessage = result.error.message,
                            statusMessage = "Cashout failed"
                        )
                    }
                }
            }
        }
    }

    private fun buildCellsFromRounds(rounds: List<Round>): List<CellState> {
        val cells = MutableList(25) { CellState(it / 5, it % 5) }
        rounds.forEach { round ->
            val idx = round.row * 5 + round.col
            cells[idx] = cells[idx].copy(
                isSafe = round.result == 2,
                isMine = round.result == 1,
                probability = null
            )
        }
        return cells
    }
}
